#include <stdio.h>
#include <string.h>
#include "export.h"

/* The routines in this list have been done */
extern void pgarro_();
extern void pgask_();
extern void pgaxis_();
extern int pgbeg_();
extern void pgbin_();
extern void pgbox_();
extern void pgcirc_();
extern void pgclos_();
extern void pgdraw_();
extern void pgend_();
extern void pgenv_();
extern void pgeras_();
extern void pgerr1_();
extern void pgerrb_();
extern void pgerrx_();
extern void pgerry_();
extern void pgetxt_();
extern void pghist_();
extern void pgiden_();
extern void pglab_();
extern void pgline_();
extern void pgmove_();
extern void pgmtxt_();
extern int pgopen_();
extern void pgpage_();
extern void pgpap_();
extern void pgpnts_();
extern void pgpoly_();
extern void pgpt_();
extern void pgpt1_();
extern void pgptxt_();
extern void pgsvp_();
extern void pgswin_();

/*  The ones in this list still need wrapping  */
extern int pgband_();
extern void pgbbuf_();
extern void pgconb_();
extern void pgconf_();
extern void pgconl_();
extern void pgcons_();
extern void pgcont_();
extern void pgctab_();
extern int pgcurs_();
extern void pgebuf_();
extern void pggray_();
extern void pghi2d_();
extern void pgimag_();
extern void pglcur_();
extern void pgldev_();
extern void pglen_();
extern void pgncur_();
extern void pgnumb_();
extern void pgolin_();
extern void pgpanl_();
extern void pgpixl_();
extern void pgqah_();
extern void pgqcf_();
extern void pgqch_();
extern void pgqci_();
extern void pgqcir_();
extern void pgqclp_();
extern void pgqcol_();
extern void pgqcr_();
extern void pgqcs_();
extern void pgqdt_();
extern void pgqfs_();
extern void pgqhs_();
extern void pgqid_();
extern void pgqinf_();
extern void pgqitf_();
extern void pgqls_();
extern void pgqlw_();
extern void pgqndt_();
extern void pgqpos_();
extern void pgqtbg_();
extern void pgqtxt_();
extern void pgqvp_();
extern void pgqvsz_();
extern void pgqwin_();
extern void pgrect_();
extern float pgrnd_();
extern void pgrnge_();
extern void pgsah_();
extern void pgsave_();
extern void pgscf_();
extern void pgsch_();
extern void pgsci_();
extern void pgscir_();
extern void pgsclp_();
extern void pgscr_();
extern void pgscrl_();
extern void pgscrn_();
extern void pgsfs_();
extern void pgshls_();
extern void pgshs_();
extern void pgsitf_();
extern void pgslct_();
extern void pgsls_();
extern void pgslw_();
extern void pgstbg_();
extern void pgsubp_();
extern void pgtbox_();
extern void pgtext_();
extern void pgtick_();
extern void pgunsa_();
extern void pgupdt_();
extern void pgvect_();
extern void pgvsiz_();
extern void pgvstd_();
extern void pgwedg_();
extern void pgwnad_();
  
IDL_LONG idl_pgbeg
  (int      argc,
   void *   argv[])
{ 
   IDL_LONG r_value;

   IDL_LONG   *un;
   IDL_STRING *dev;
   IDL_LONG   *nxsub;
   IDL_LONG   *nysub;

   int argct = 0;

   un      = (IDL_LONG *)argv[argct++];
   dev    =  (IDL_STRING *)argv[argct++];
   nxsub   = (IDL_LONG *)argv[argct++];
   nysub   = (IDL_LONG *)argv[argct];

   fprintf(stderr,"Hello %d\n",(int) *un);
   fprintf(stderr,"Hello %s\n", dev->s);
   fprintf(stderr,"Hello %d\n",(int) *nxsub);
   fprintf(stderr,"Hello %d\n",(int) *nysub);

   r_value = pgbeg_(un, dev->s, nxsub, nysub, dev->slen);
   return r_value;
}

IDL_LONG idl_pgend()
{ 
  pgend_();
  return 0;
}

IDL_LONG idl_pgbox
  (int      argc,
   void *   argv[])
{

  int argct = 0;
  IDL_STRING *xopt = (IDL_STRING *)argv[argct++]; 
  float      *xtick= (float *)argv[argct++];
  IDL_LONG   *nxsub= (IDL_LONG *)argv[argct++];
  IDL_STRING *yopt = (IDL_STRING *)argv[argct++];
  float      *ytick= (float *)argv[argct++];
  IDL_LONG   *nysub= (IDL_LONG *)argv[argct++];

  pgbox_(xopt->s, xtick, nxsub, yopt->s, ytick, nysub, xopt->slen, yopt->slen);
  return 0;
}


IDL_LONG idl_pgarro
  (int      argc,
   void *   argv[])
{
  pgarro_((float *)argv[0], (float *)argv[1], 
          (float *)argv[2], (float *)argv[3]);
  return 0; 
}

IDL_LONG idl_pgask
  (int      argc,
   void *   argv[])
{
  int l_flag = *((IDL_LONG *)argv[0]);
  pgask_(&l_flag);
  return 0;
}

IDL_LONG idl_pgaxis
  (int      argc,
   void *   argv[])
{
  IDL_STRING *opt = argv[0];
  pgaxis_(opt->s, (float *)argv[1], (float *)argv[2],    
                  (float *)argv[3], (float *)argv[4],    
                  (float *)argv[5], (float *)argv[6],    
                  (float *)argv[7], (IDL_LONG *)argv[8], 
                  (float *)argv[9], (float *)argv[10],   
                  (float *)argv[11], (float *)argv[12], (float *)argv[13]);
  return 0;
}

/*  Pass a long instead of logical just for ease of use  */
IDL_LONG idl_pgbin
  (int      argc,
   void *   argv[])
{
  int l_center = *((IDL_LONG *)argv[3]) ? 1:0;
  pgbin_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2], &l_center);
  return 0;
}

IDL_LONG idl_pgcirc
  (int      argc,
   void *   argv[])
{
  pgcirc_((float *)argv[0], (float *)argv[1], (float *)argv[2]);
  return 0;
}

IDL_LONG idl_pgclos()
{
  pgclos_();
  return 0;
}

IDL_LONG idl_pgdraw
  (int      argc,
   void *   argv[])
{
  pgdraw_((float *)argv[0], (float *)argv[1]);
  return 0;
}

IDL_LONG idl_pgenv
  (int      argc,
   void *   argv[])
{
  pgenv_((float *)argv[0], (float *)argv[1], 
         (float *)argv[2], (float *)argv[3],
         (IDL_LONG *)argv[4], (IDL_LONG *)argv[5]);
  return 0;
}

IDL_LONG idl_pgeras()
{
  pgeras_();
  return 0;
}

IDL_LONG idl_pgerr1
  (int      argc,
   void *   argv[])
{
  pgerr1_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2], 
         (float *)argv[3], (float *)argv[4]);
  return 0;
}

IDL_LONG idl_pgerrb
  (int      argc,
   void *   argv[])
{
  pgerrb_((IDL_LONG *)argv[0], (IDL_LONG *)argv[1], 
         (float *)argv[2], (float *)argv[3], 
         (float *)argv[4], (float *)argv[5]);
  return 0;
}

IDL_LONG idl_pgerrx
  (int      argc,
   void *   argv[])
{
  pgerrx_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2], 
         (float *)argv[3], (float *)argv[4]);
  return 0;
}

IDL_LONG idl_pgerry
  (int      argc,
   void *   argv[])
{
  pgerry_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2], 
         (float *)argv[3], (float *)argv[4]);
  return 0;
}

IDL_LONG idl_pgetxt()
{
  pgetxt_();
  return 0;
}


IDL_LONG idl_pghist
  (int      argc,
   void *   argv[])
{
  pghist_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2], 
         (float *)argv[3], (IDL_LONG *)argv[4], (IDL_LONG *)argv[5]);
  return 0;
}

IDL_LONG idl_pgiden()
{
  pgiden_();
  return 0;
}

IDL_LONG idl_pglab
  (int      argc,
   void *   argv[])
{
  IDL_STRING *xlbl   = (IDL_STRING *)argv[0];
  IDL_STRING *ylbl   = (IDL_STRING *)argv[1];
  IDL_STRING *toplbl = (IDL_STRING *)argv[2];

  pglab_(xlbl->s, ylbl->s, toplbl->s, xlbl->slen, ylbl->slen, toplbl->slen);
  return 0;
}

IDL_LONG idl_pgline
  (int      argc,
   void *   argv[])
{
  pgline_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2]); 
  return 0;
}

IDL_LONG idl_pgmove
  (int      argc,
   void *   argv[])
{
  pgmove_((float *)argv[0], (float *)argv[1]); 
  return 0;
}

IDL_LONG idl_pgmtxt
  (int      argc,
   void *   argv[])
{
  IDL_STRING *side   = (IDL_STRING *)argv[0];
  IDL_STRING *text   = (IDL_STRING *)argv[4];

  pgmtxt_(side->s, 
         (float *)argv[1], (float *)argv[2], (float *)argv[3], 
         text->s, side->slen, text->slen);
  return 0;
}

IDL_LONG idl_pgopen
  (int      argc,
   void *   argv[])
{
  IDL_STRING *dev    = (IDL_STRING *)argv[0];
  IDL_LONG r_value;

  r_value = pgopen_(dev->s, dev->slen);
  return r_value;
}

IDL_LONG idl_pgpage()
{
  pgpage_();
  return 0;
}

IDL_LONG idl_pgpap
  (int      argc,
   void *   argv[])
{
  pgpap_((float *)argv[0], (float *)argv[1]); 
  return 0;
}

IDL_LONG idl_pgpnts
  (int      argc,
   void *   argv[])
{
  pgpnts_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2], 
         (IDL_LONG *)argv[3], (IDL_LONG *)argv[4]);
  return 0;
}

IDL_LONG idl_pgpoly
  (int      argc,
   void *   argv[])
{
  pgpoly_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2]); 
  return 0;
}

IDL_LONG idl_pgpt
  (int      argc,
   void *   argv[])
{
  pgpt_((IDL_LONG *)argv[0], (float *)argv[1], (float *)argv[2], 
         (IDL_LONG *)argv[3]);
  return 0;
}

IDL_LONG idl_pgpt1
  (int      argc,
   void *   argv[])
{
  pgpt1_((float *)argv[0], (float *)argv[1], (IDL_LONG *)argv[2]);
  return 0;
}

IDL_LONG idl_pgptxt
  (int      argc,
   void *   argv[])
{
  IDL_STRING *text   = (IDL_STRING *)argv[4];

  pgptxt_((float *)argv[0], (float *)argv[1], 
          (float *)argv[2], (float *)argv[3], 
          text->s, text->slen);
  return 0;
}


IDL_LONG idl_pgsvp
  (int      argc,
   void *   argv[])
{
  pgsvp_((float *)argv[0], (float *)argv[1], 
         (float *)argv[2], (float *)argv[3]); 
  return 0;
}

IDL_LONG idl_pgswin
  (int      argc,
   void *   argv[])
{
  pgswin_((float *)argv[0], (float *)argv[1], 
          (float *)argv[2], (float *)argv[3]); 
  return 0;
}

